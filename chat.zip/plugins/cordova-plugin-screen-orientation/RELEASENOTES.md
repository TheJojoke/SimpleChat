### 3.0.1 (Dec 27, 2017)
* [CB-13710](https://issues.apache.org/jira/browse/CB-13710) Fix to allow 3.0.0 version install (#28)

