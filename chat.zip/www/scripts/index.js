﻿/*function sape(e)
{
    if (document.getElementById("dos").style.display == "block")
        {
        document.getElementById("dos").style.display = "none";
        document.getElementById("tres").style.display = "none";
        document.getElementById("cuatro").style.display = "none";
        document.getElementById("cinco").style.display = "none";
        document.getElementById("seis").style.display = "none";
        document.getElementById("siete").style.display = "none";
        document.getElementById("ocho").style.display = "none";
        document.getElementById("nueve").style.display = "none";
          }
}*/

var delCont = 0;
var arr = new Array;

var rojo = "rgb(255, 59, 59)";
var verde = "rgb(132, 182, 85)";
var azul = "rgb(38, 160, 218)";

function newTask() {
    var li = document.createElement("li");
    li.className = "deployment";
    var input = document.getElementById("input").value;
    var textValue = document.createTextNode(input);
    var spanText = document.createElement("span");
    spanText.className = "textSpan";
    spanText.appendChild(textValue);
    li.appendChild(spanText);
    var progressBar = document.getElementById("pBar");

    var counter = document.getElementById("counter");
    var counterChecked = document.getElementById("counterChecked");
    var counterValue = counter.firstChild.nodeValue;
    var counterValueChecked = counterChecked.firstChild.nodeValue;

    if (input == "") {
        alert("You can't add an empty task!");
    } else {
        counterValue++;
        li.id = counterValue;
        li.value = false;
        document.getElementById("list").appendChild(li);
        document.getElementById("counter").innerHTML = counterValue;
        value = counterValueChecked * 100 / counterValue;
        if (Number.isNaN(value)) {
            progressBar.style.width = 0 + "%";
            progressBar.innerHTML = 0 + "%";
        } else {
            progressBar.style.width = Math.trunc(counterValueChecked * 100 / counterValue) + "%";
            progressBar.innerHTML = Math.trunc(counterValueChecked * 100 / counterValue) + "%";
        }
    }
    document.getElementById("input").value = "";

    var span = document.createElement("span");
    var del = document.createTextNode("\u00D7");
    span.className = "delStyle";
    span.appendChild(del);
    li.appendChild(span);

    var spanCheck = document.createElement("span");
    var check = document.createTextNode("\u2713");
    spanCheck.className = "checkStyle";
    spanCheck.id = counterValue;
    spanCheck.value = false;
    spanCheck.appendChild(check);
    li.appendChild(spanCheck);

    var spanInfo = document.createElement("span");
    var info = document.createTextNode("\u25b6");
    info.className = "unicodeArrow";
    spanInfo.className = "infoStyle";
    spanInfo.value = false;
    spanInfo.appendChild(info);
    li.appendChild(spanInfo);


    var close = document.getElementsByClassName("delStyle");
    var checkedTask = document.getElementsByClassName("checkStyle");
    var infoTask = document.getElementsByClassName("infoStyle");

    var panel = document.createElement("div");
    panel.style.display = 'none';
    panel.value = "false";
    panel.className = "panel";
    arr.push(panel);

    for (var i = 0; i < close.length; i++)
     {
        close[i].onclick = function () {
            var div = this.parentElement;
            div.style.display = "none";
            if (div.value == true) {
                counterValueChecked--;
            }
            counterValue--;
            delCont++;
            document.getElementById("counter").innerHTML = counterValue;
            document.getElementById("counterChecked").innerHTML = counterValueChecked;

            value = counterValueChecked * 100 / counterValue;
            if (Number.isNaN(value)) {
                progressBar.style.width = 0 + "%";
                progressBar.innerHTML = 0 + "%";
            } else {
                progressBar.style.width = Math.trunc(counterValueChecked * 100 / counterValue) + "%";
                progressBar.innerHTML = Math.trunc(counterValueChecked * 100 / counterValue) + "%";
            }
        }

        checkedTask[i].onclick = function check() {
            var div2 = this.parentElement;
            div2.value = true;
            div2.style.background = verde;
            counterValueChecked++;
            //checkedTask[i-1].value = true;
            document.getElementById("counterChecked").innerHTML = counterValueChecked;
            value = counterValueChecked * 100 / counterValue;
            if (Number.isNaN(value)) {
                progressBar.style.width = 0 + "%";
                progressBar.innerHTML = 0 + "%";
            } else {
                progressBar.style.width = Math.trunc(counterValueChecked * 100 / counterValue) + "%";
                progressBar.innerHTML = Math.trunc(counterValueChecked * 100 / counterValue) + "%";
            }
            this.onclick = null;
        }

        infoTask[i].onclick = function () {
            var div3 = this.parentElement;
            this.classList.toggle("infoStyle-active");
            div3.appendChild(arr[div3.id - 1]);

            //alert("pfff " + checkedTask[div3.id-1].value);

            var color;

            if (this.value == false) {
                document.getElementById("colorHex").innerHTML = window.getComputedStyle(div3).backgroundColor;
                div3.style.background = azul;
                this.value = true;
            } else {

                //if(color == rojo){
                //alert("que es rojo leches " + color);
                //div3.style.background = rojo;
                //this.value = false;
                //}else{
                //alert("que es rojo leches " + color);
                div3.style.background = document.getElementById("colorHex").innerHTML;
                this.value = false;
                //}

            }

            if (/*window.getComputedStyle(panel).display === 'block'*/ arr[div3.id - 1].value == false) {
                arr[div3.id - 1].style.display = 'none';
                arr[div3.id - 1].value = true;
                return;
            } else {
                arr[div3.id - 1].value = false;
                arr[div3.id - 1].style.display = 'block';
                return;
            }
        }
    }

}
