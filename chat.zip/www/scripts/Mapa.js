﻿/*function ubicate() {
    var onSuccess = function (position)
    {
        document.getElementById("latitude").innerHTML = ('Latitude: ' + position.coords.latitude);
        document.getElementById("longitude").innerHTML = ('Longitude: ' + position.coords.longitude);
        document.getElementById("altitude").innerHTML = ('Altitude: ' + position.coords.altitude);
        document.getElementById("accuracy").innerHTML = ('Accuracy: ' + position.coords.accuracy);
        document.getElementById("altitudeaccuracy").innerHTML = ('Altitude Accuracy: ' + position.coords.altitudeAccuracy);
        document.getElementById("heading").innerHTML = ('Heading: ' + position.coords.heading);
        document.getElementById("speed").innerHTML = ('Speed: ' + position.coords.speed);
        document.getElementById("timestamp").innerHTML = ('Timestamp: ' + position.timestamp);
    };

    // onError Callback receives a PositionError object
    //
    function onError(error) {
        alert('code: ' + error.code + '\n' +
            'message: ' + error.message + '\n');
    }

    navigator.geolocation.getCurrentPosition(onSuccess, onError);
}
function ubicado()
{
    ubicate();
}*/

function comment() {
}
function GetLocation() {
    if (navigator.geolocation) {
        let gw = navigator.geolocation.getCurrentPosition(ShowPosition);
        navigator.geolocation.clearWatch(gw);
    }
    else {
        x.innerHTML = "Geolocation is not supported by your browser.";
    }

}
function ShowPosition(position) {
    var latlon = { lat: position.coords.latitude, lng: position.coords.longitude };
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 15,
        center: latlon,
        mapTypeId: 'satellite'
    });
    var marker = new google.maps.Marker({
        position: latlon,
        map: map,
        title: "User Location"
    });
    var x = document.getElementById("api");
    x.innerHTML = "<br><b>Latitude: " +
        position.coords.latitude + "</b>" +
        "<br><b>Longitude: " +
        position.coords.longitude + "</b>"+
        "<br><b>Speed: " +
        position.coords.speed + "</b>";
}

function initMap() {
    var center = { lat: 45.478489, lng: 9.122150 };
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 1,
        center: center,
        mapTypeId: 'satellite'
    });
}